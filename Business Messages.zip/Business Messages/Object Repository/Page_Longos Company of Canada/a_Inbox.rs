<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Inbox</name>
   <tag></tag>
   <elementGuidId>b523e04b-4230-4d7f-bd3c-0b734901ead8</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//li[@id='menu-bm-inbox']/a</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>#menu-bm-inbox > a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>4ef1faf9-73ec-4127-b0d1-8bbbec738975</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/BusinessMessages</value>
      <webElementGuid>0410f087-d7fc-4282-aeb2-d1d3879d649d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                                    
                                    
                                        Inbox
                                        !
                                    
                                </value>
      <webElementGuid>3df8ac61-628c-4b9e-8655-9c38ceee9dd2</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;menu-bm-inbox&quot;)/a[1]</value>
      <webElementGuid>6018b388-241b-405b-be67-92f06d2a6e2c</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//li[@id='menu-bm-inbox']/a</value>
      <webElementGuid>0a2be6da-7811-42b4-83c5-24bf5efba6ea</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Business Messages'])[1]/following::a[1]</value>
      <webElementGuid>fb88bf7b-3706-4371-be4c-8c69b3f8a3e3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Performance Reports'])[1]/following::a[2]</value>
      <webElementGuid>a065915e-6bd6-4f24-9f82-e57136415de1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/BusinessMessages')]</value>
      <webElementGuid>67ed56f1-9a7d-421f-96f0-dc6832780400</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[4]/ul/li/a</value>
      <webElementGuid>c2e55c3c-2507-4cd4-9c2b-ac9760e7c095</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/BusinessMessages' and (text() = '
                                    
                                    
                                        Inbox
                                        !
                                    
                                ' or . = '
                                    
                                    
                                        Inbox
                                        !
                                    
                                ')]</value>
      <webElementGuid>c6e5b7bc-2d25-4e66-9624-54807fa783cb</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
