<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Message  4.54 pm</name>
   <tag></tag>
   <elementGuidId>91230b36-cb90-4712-9ef2-e9992373b460</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='54']/div[2]/div[2]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>#54 > div.col-sm-10.bm-card-container > div.bm-card-message</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>3e980f8d-16cb-47e0-9a0f-9186fe4c3047</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>bm-card-message</value>
      <webElementGuid>770b59e0-93c2-4f1c-abeb-e5e33b93e25a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Message @ 4.54 pm</value>
      <webElementGuid>a6cd4357-1d1a-43d1-acd4-acc331ad35b8</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;54&quot;)/div[@class=&quot;col-sm-10 bm-card-container&quot;]/div[@class=&quot;bm-card-message&quot;]</value>
      <webElementGuid>4333b03c-d211-4d21-b478-8774c1ca40f0</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='54']/div[2]/div[2]</value>
      <webElementGuid>1684e09b-dbda-4b56-a66c-59c30c039717</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Rahul Menon'])[3]/following::div[2]</value>
      <webElementGuid>c24641d2-9237-429f-8222-d7c6c1440647</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='RM'])[3]/following::div[5]</value>
      <webElementGuid>7599e0ab-2b92-4057-841a-27dee57bf742</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Claimed by you'])[2]/preceding::div[1]</value>
      <webElementGuid>d7cbbafa-1f5d-49fc-bed7-508b2d6ae3ee</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='RM'])[4]/preceding::div[2]</value>
      <webElementGuid>cd580123-312b-4a5a-ac05-6784daf11007</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Message @ 4.54 pm']/parent::*</value>
      <webElementGuid>eafbf5e7-d890-451a-b4d3-5690d4e2ce38</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div/div/div/div[2]/div[2]/div[2]</value>
      <webElementGuid>1f0b8087-2428-4fbe-8d27-63764fc4033c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = 'Message @ 4.54 pm' or . = 'Message @ 4.54 pm')]</value>
      <webElementGuid>7bbe07f4-cbb0-4479-9c47-8a699d8bde8b</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
