<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Rahul Menon</name>
   <tag></tag>
   <elementGuidId>9c90c05e-693d-45f0-97b1-d07e5b6e5e25</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='56']/div[2]/div/div</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.bm-card-details.bold > div</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>43d12b6d-4b25-4265-82a6-7dc3d4576d71</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Rahul Menon</value>
      <webElementGuid>4f9a7442-0914-4eef-9140-122194db1fcb</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;56&quot;)/div[@class=&quot;col-sm-10 bm-card-container&quot;]/div[@class=&quot;bm-card-details bold&quot;]/div[1]</value>
      <webElementGuid>9cefb768-401e-4ae1-af86-62a580242394</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>f988b9e4-b54f-4d27-817a-cea50a0fbe85</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Rahul Menon</value>
      <webElementGuid>1ff7f169-664c-461a-a84a-e9d4fd26a08b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;54&quot;)/div[@class=&quot;col-sm-10 bm-card-container&quot;]/div[@class=&quot;bm-card-details bold&quot;]/div[1]</value>
      <webElementGuid>4c97a67b-4310-45ca-8838-d63134b80d51</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='56']/div[2]/div/div</value>
      <webElementGuid>336eb36d-3cba-4a9b-b66d-17bca32e2792</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='RM'])[1]/following::div[3]</value>
      <webElementGuid>f7b520e6-0ad1-4c11-9da7-b9e66a5730aa</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='(10)'])[1]/following::div[6]</value>
      <webElementGuid>023ea3a7-5b68-40be-9505-535838628b0d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='******* * **** **'])[1]/preceding::div[2]</value>
      <webElementGuid>c42766ba-00bf-4ba3-a500-5c1cfa3a29dd</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='JC'])[1]/preceding::div[4]</value>
      <webElementGuid>5d3a5ec8-e06a-4db9-ba86-fb55fbd9499c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Rahul Menon']/parent::*</value>
      <webElementGuid>dfec3f4d-5c6a-48da-b4c9-e5a90e382e15</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div/div/div/div/div[2]/div/div[2]/div/div</value>
      <webElementGuid>1f9329d7-aac3-472f-8459-a8e3924ce325</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = 'Rahul Menon' or . = 'Rahul Menon')]</value>
      <webElementGuid>55609743-5151-474e-b8e2-87e1e86079c0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='54']/div[2]/div/div</value>
      <webElementGuid>a1cf01af-efbf-4c1d-b365-9c7a89d7e3a5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='(11)'])[1]/following::div[6]</value>
      <webElementGuid>d951eac1-6769-4d39-8f46-a5c38550504a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='RM'])[2]/preceding::div[4]</value>
      <webElementGuid>636a9709-7dc7-4ac4-a576-5e16472c1841</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
