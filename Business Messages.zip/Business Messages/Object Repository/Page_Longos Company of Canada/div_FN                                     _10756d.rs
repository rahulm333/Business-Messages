<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_FN                                     _10756d</name>
   <tag></tag>
   <elementGuidId>9150edc9-5d80-48c9-a35a-9a39fc7da44c</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='13']</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>#13</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>c96119b1-66d0-4f74-b2c2-09782c0a810a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>bm-card</value>
      <webElementGuid>7b5fe5b4-950b-40b6-9194-dcc664834b6f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>13</value>
      <webElementGuid>154aaba0-8552-4b6d-8151-414b01f524e7</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                    FN
                    
                        
                            Franklin Noel
                            11-15 
                        
                        *** *** * **** *** ******
                        
                    
                </value>
      <webElementGuid>235b7453-3073-4980-b97f-5eea229a22cc</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;13&quot;)</value>
      <webElementGuid>17192741-0951-4fa8-b48b-d2defc8d104a</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//div[@id='13']</value>
      <webElementGuid>c0ad8909-5642-4ffb-9379-2e0a8a1f627c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='unclaimed-conversations']/div[8]</value>
      <webElementGuid>28d00707-52d4-4b3f-8328-400c3305a62c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='**** ** *** ******* **** **** *****...'])[1]/following::div[2]</value>
      <webElementGuid>082c0319-8815-4d9a-86e0-c77952e5afdd</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Juliana de Carvalho'])[4]/following::div[4]</value>
      <webElementGuid>c74622eb-70b5-401f-8de4-de363bdd4eda</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div[8]</value>
      <webElementGuid>ae58b669-5eed-4a56-9995-4f0b70f342a4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[@id = '13' and (text() = '
                    FN
                    
                        
                            Franklin Noel
                            11-15 
                        
                        *** *** * **** *** ******
                        
                    
                ' or . = '
                    FN
                    
                        
                            Franklin Noel
                            11-15 
                        
                        *** *** * **** *** ******
                        
                    
                ')]</value>
      <webElementGuid>37e2109b-6046-434a-9429-742b5b7c28c0</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
