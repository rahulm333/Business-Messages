<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>h4_Unclaimed Conversations (5)</name>
   <tag></tag>
   <elementGuidId>58830898-6266-4162-8ea8-cd7d8cad15ec</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='page-content']/div[2]/div/div/div/div/h4</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>h4.section-title.text-primary</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>h4</value>
      <webElementGuid>8c8a6fcb-11c5-488a-a5dc-e401ed17d08f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>section-title text-primary</value>
      <webElementGuid>3686a148-7941-4182-b1a1-5a47876af833</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Unclaimed Conversations (5)</value>
      <webElementGuid>486725d1-9f9b-40dd-9a59-701125522a8d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;page-content&quot;)/div[@class=&quot;business-messages-container container-fluid&quot;]/div[@class=&quot;row border-top&quot;]/div[@class=&quot;col-sm-12 col-md-4 col-lg-3 business-messages-border&quot;]/div[@class=&quot;unclaimed-conversations-container&quot;]/div[@class=&quot;row unclaimed-conversations&quot;]/h4[@class=&quot;section-title text-primary&quot;]</value>
      <webElementGuid>11630bb3-6627-4f2a-82f2-f42cba612fa5</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='page-content']/div[2]/div/div/div/div/h4</value>
      <webElementGuid>1006d183-9f4e-4127-99dd-c57addc88641</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Read Manual'])[1]/following::h4[1]</value>
      <webElementGuid>7b0d3b35-da62-4492-ad92-bcbc2c239e11</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Business Messages Conversation Channel'])[1]/following::h4[1]</value>
      <webElementGuid>ed100018-a15b-4f86-8905-e8ebaea0d16c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='JC'])[1]/preceding::h4[1]</value>
      <webElementGuid>bf5d5e58-1928-41e5-b9b8-c3ebedaaeb37</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Unclaimed Conversations']/parent::*</value>
      <webElementGuid>87044ffd-82be-44e3-893d-ee3f4d9c0ced</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//h4</value>
      <webElementGuid>82ae6828-66f8-4715-b054-38965f6febca</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//h4[(text() = 'Unclaimed Conversations (5)' or . = 'Unclaimed Conversations (5)')]</value>
      <webElementGuid>9c4c2ab3-78fc-4ef4-b33c-d28e8f48a670</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
