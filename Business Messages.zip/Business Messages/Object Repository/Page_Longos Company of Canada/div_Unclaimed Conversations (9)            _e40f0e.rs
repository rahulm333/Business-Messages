<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Unclaimed Conversations (9)            _e40f0e</name>
   <tag></tag>
   <elementGuidId>4c7df061-12de-4cf5-ba6e-f24da9adff01</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='page-content']/div[2]/div</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.row.border-top</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>115cd2a7-091f-4978-9cec-fcf6f4e5f7ef</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>row border-top</value>
      <webElementGuid>74f0f38c-f1ca-4bad-bf7f-87c7703c5f56</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
        
            
                
                    
                        
                            
                            
                        
                    

                    Unclaimed Conversations (9)
                    
                
                    JC
                    
                        
                            Juliana de Carvalho
                            06-28 
                        
                        **** * **** ******* 
                        
                    
                                
            
                
                    JE
                    
                        
                            Jeff
                            06-21 
                        
                        **** ** **** **** ****** 
                        
                    
                                
            
                
                    JC
                    
                        
                            Juliana de Carvalho
                            06-21 
                        
                        **** **** ****** ******** 
                        
                    
                                
            
                
                    RM
                    
                        
                            Rahul Menon
                            06-07 
                        
                        *** ***** *******
                        
                    
                                
            
                
            
            
                Claimed Conversations (26)
                
                        
                        
                        
                            My Conversations (22)
                            Other Conversations (4)
                        
                        
                        
                            
                
                    RM
                    
                        
                            Rahul Menon
                            07-05 
                        
                        Message @ 4.54 pm
                        Claimed by you
                    
                                
            
                
                    RM
                    
                        
                            Rahul Menon
                            07-05 
                        
                        Message @ 4.49 pm
                        Claimed by you
                    
                                
            
                
                    DT
                    
                        
                            dac test
                            05-15 
                        
                        Hello
                        Claimed by you
                    
                                
            
                
                    R
                    
                        
                            R
                            04-14 
                        
                        Sounds good
                        Claimed by you
                    
                                
            
                            
                            
                        

                
            
        
        
            
        
            RM 
            Rahul Menon
        
        
        
            
            
                
                    
                        
                        06-21 3:45 PM
                    
                    
                    This is a new message from Madrid location
                    
                
                
            
            
            
                
                    
                        larry_nn_email
                        06-21 3:55 PM
                    
                    
                    Message from Madrid location is well received on dashboard
                    
                
                Delivered and Read
            
            
            
                
                    
                        
                        06-26 9:03 PM
                    
                    
                    Hello! New message from Madrid @ 9.02 pm
                    
                
                
            
            
            
                
                    
                        aarcha_lekha
                        06-26 9:14 PM
                    
                    
                    Message @9.02 pm is received
                    
                
                Delivered and Read
            
            
            
                
                    
                        
                        06-28 5:18 PM
                    
                    
                    Message from Madrid @ 5.15 pm on 06-28
                    
                
                
            
            
            
                
                    
                        aarcha_lekha
                        06-28 5:22 PM
                    
                    
                    Message is received 
                    
                
                Delivered and Read
            
            
            
                
                    
                        
                        07-05 4:56 PM
                    
                    
                    Message @ 4.54 pm
                    
                
                
            
            
            
                
                    
                        aarcha_lekha
                        07-05 5:22 PM
                    
                    
                    Message is received on dashboard
                    
                
                Delivered and Read
            
            

                
                    
                        To respond, claim this conversation.
                        Claim conversation
                    
                
                
                    
                        
                        This conversation has been claimed by N / A
                        Request to claim
                    
                
                
                    
                        
                            
                            
                                Send
                            
                        
                    
                
                
                    
                        Unclaim conversation to allow another dashboard user to respond.
                    
                

        
        
            
            Customer Information
            
                
                    
                        Name
                        Rahul Menon
                    

                     
                        Device Locale
                        en-IN                    
                    
                    
                    
                        Business Location
                            
                                999901 Bathurst St, Toronto, 
                                ON, CA
                                +14165557042 
                                9000327042 
                                            
                    
                
            
        
    </value>
      <webElementGuid>ab75ffa3-2064-43d8-b2ce-7b4481ca43e8</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;page-content&quot;)/div[@class=&quot;business-messages-container container-fluid&quot;]/div[@class=&quot;row border-top&quot;]</value>
      <webElementGuid>f212c329-5fc3-4e49-a529-d0ce5fbc2362</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='page-content']/div[2]/div</value>
      <webElementGuid>58012f82-2944-40bb-9120-e74825ccc154</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Read Manual'])[1]/following::div[2]</value>
      <webElementGuid>fcd85b97-afcd-40a0-8559-b604fdeebead</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Business Messages Conversation Channel'])[1]/following::div[2]</value>
      <webElementGuid>997e6b7c-a2f5-43f5-9464-a2984755e0d4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[3]/div[2]/div</value>
      <webElementGuid>11316222-b7f4-44dc-a92e-f241ef2d2006</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = '
        
            
                
                    
                        
                            
                            
                        
                    

                    Unclaimed Conversations (9)
                    
                
                    JC
                    
                        
                            Juliana de Carvalho
                            06-28 
                        
                        **** * **** ******* 
                        
                    
                                
            
                
                    JE
                    
                        
                            Jeff
                            06-21 
                        
                        **** ** **** **** ****** 
                        
                    
                                
            
                
                    JC
                    
                        
                            Juliana de Carvalho
                            06-21 
                        
                        **** **** ****** ******** 
                        
                    
                                
            
                
                    RM
                    
                        
                            Rahul Menon
                            06-07 
                        
                        *** ***** *******
                        
                    
                                
            
                
            
            
                Claimed Conversations (26)
                
                        
                        
                        
                            My Conversations (22)
                            Other Conversations (4)
                        
                        
                        
                            
                
                    RM
                    
                        
                            Rahul Menon
                            07-05 
                        
                        Message @ 4.54 pm
                        Claimed by you
                    
                                
            
                
                    RM
                    
                        
                            Rahul Menon
                            07-05 
                        
                        Message @ 4.49 pm
                        Claimed by you
                    
                                
            
                
                    DT
                    
                        
                            dac test
                            05-15 
                        
                        Hello
                        Claimed by you
                    
                                
            
                
                    R
                    
                        
                            R
                            04-14 
                        
                        Sounds good
                        Claimed by you
                    
                                
            
                            
                            
                        

                
            
        
        
            
        
            RM 
            Rahul Menon
        
        
        
            
            
                
                    
                        
                        06-21 3:45 PM
                    
                    
                    This is a new message from Madrid location
                    
                
                
            
            
            
                
                    
                        larry_nn_email
                        06-21 3:55 PM
                    
                    
                    Message from Madrid location is well received on dashboard
                    
                
                Delivered and Read
            
            
            
                
                    
                        
                        06-26 9:03 PM
                    
                    
                    Hello! New message from Madrid @ 9.02 pm
                    
                
                
            
            
            
                
                    
                        aarcha_lekha
                        06-26 9:14 PM
                    
                    
                    Message @9.02 pm is received
                    
                
                Delivered and Read
            
            
            
                
                    
                        
                        06-28 5:18 PM
                    
                    
                    Message from Madrid @ 5.15 pm on 06-28
                    
                
                
            
            
            
                
                    
                        aarcha_lekha
                        06-28 5:22 PM
                    
                    
                    Message is received 
                    
                
                Delivered and Read
            
            
            
                
                    
                        
                        07-05 4:56 PM
                    
                    
                    Message @ 4.54 pm
                    
                
                
            
            
            
                
                    
                        aarcha_lekha
                        07-05 5:22 PM
                    
                    
                    Message is received on dashboard
                    
                
                Delivered and Read
            
            

                
                    
                        To respond, claim this conversation.
                        Claim conversation
                    
                
                
                    
                        
                        This conversation has been claimed by N / A
                        Request to claim
                    
                
                
                    
                        
                            
                            
                                Send
                            
                        
                    
                
                
                    
                        Unclaim conversation to allow another dashboard user to respond.
                    
                

        
        
            
            Customer Information
            
                
                    
                        Name
                        Rahul Menon
                    

                     
                        Device Locale
                        en-IN                    
                    
                    
                    
                        Business Location
                            
                                999901 Bathurst St, Toronto, 
                                ON, CA
                                +14165557042 
                                9000327042 
                                            
                    
                
            
        
    ' or . = '
        
            
                
                    
                        
                            
                            
                        
                    

                    Unclaimed Conversations (9)
                    
                
                    JC
                    
                        
                            Juliana de Carvalho
                            06-28 
                        
                        **** * **** ******* 
                        
                    
                                
            
                
                    JE
                    
                        
                            Jeff
                            06-21 
                        
                        **** ** **** **** ****** 
                        
                    
                                
            
                
                    JC
                    
                        
                            Juliana de Carvalho
                            06-21 
                        
                        **** **** ****** ******** 
                        
                    
                                
            
                
                    RM
                    
                        
                            Rahul Menon
                            06-07 
                        
                        *** ***** *******
                        
                    
                                
            
                
            
            
                Claimed Conversations (26)
                
                        
                        
                        
                            My Conversations (22)
                            Other Conversations (4)
                        
                        
                        
                            
                
                    RM
                    
                        
                            Rahul Menon
                            07-05 
                        
                        Message @ 4.54 pm
                        Claimed by you
                    
                                
            
                
                    RM
                    
                        
                            Rahul Menon
                            07-05 
                        
                        Message @ 4.49 pm
                        Claimed by you
                    
                                
            
                
                    DT
                    
                        
                            dac test
                            05-15 
                        
                        Hello
                        Claimed by you
                    
                                
            
                
                    R
                    
                        
                            R
                            04-14 
                        
                        Sounds good
                        Claimed by you
                    
                                
            
                            
                            
                        

                
            
        
        
            
        
            RM 
            Rahul Menon
        
        
        
            
            
                
                    
                        
                        06-21 3:45 PM
                    
                    
                    This is a new message from Madrid location
                    
                
                
            
            
            
                
                    
                        larry_nn_email
                        06-21 3:55 PM
                    
                    
                    Message from Madrid location is well received on dashboard
                    
                
                Delivered and Read
            
            
            
                
                    
                        
                        06-26 9:03 PM
                    
                    
                    Hello! New message from Madrid @ 9.02 pm
                    
                
                
            
            
            
                
                    
                        aarcha_lekha
                        06-26 9:14 PM
                    
                    
                    Message @9.02 pm is received
                    
                
                Delivered and Read
            
            
            
                
                    
                        
                        06-28 5:18 PM
                    
                    
                    Message from Madrid @ 5.15 pm on 06-28
                    
                
                
            
            
            
                
                    
                        aarcha_lekha
                        06-28 5:22 PM
                    
                    
                    Message is received 
                    
                
                Delivered and Read
            
            
            
                
                    
                        
                        07-05 4:56 PM
                    
                    
                    Message @ 4.54 pm
                    
                
                
            
            
            
                
                    
                        aarcha_lekha
                        07-05 5:22 PM
                    
                    
                    Message is received on dashboard
                    
                
                Delivered and Read
            
            

                
                    
                        To respond, claim this conversation.
                        Claim conversation
                    
                
                
                    
                        
                        This conversation has been claimed by N / A
                        Request to claim
                    
                
                
                    
                        
                            
                            
                                Send
                            
                        
                    
                
                
                    
                        Unclaim conversation to allow another dashboard user to respond.
                    
                

        
        
            
            Customer Information
            
                
                    
                        Name
                        Rahul Menon
                    

                     
                        Device Locale
                        en-IN                    
                    
                    
                    
                        Business Location
                            
                                999901 Bathurst St, Toronto, 
                                ON, CA
                                +14165557042 
                                9000327042 
                                            
                    
                
            
        
    ')]</value>
      <webElementGuid>91b2ea6c-3948-45bc-b107-dfe6bb5b405d</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
