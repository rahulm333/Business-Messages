<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>h4_Unclaimed Conversations (7)</name>
   <tag></tag>
   <elementGuidId>99f483c9-953b-4fad-a2d0-c140bf2ad0f0</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='page-content']/div[2]/div/div/div/div/h4</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>h4.section-title.text-primary</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>h4</value>
      <webElementGuid>34e564b2-ae45-4743-8d80-b8a5ef2a2fea</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>section-title text-primary</value>
      <webElementGuid>bfe02816-fa43-447c-887d-044a6cecf766</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Unclaimed Conversations (7)</value>
      <webElementGuid>4f4ed135-3790-475a-97f0-48844d989944</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;page-content&quot;)/div[@class=&quot;business-messages-container container-fluid&quot;]/div[@class=&quot;row border-top&quot;]/div[@class=&quot;col-sm-12 col-md-4 col-lg-3 business-messages-border&quot;]/div[@class=&quot;unclaimed-conversations-container&quot;]/div[@class=&quot;row unclaimed-conversations&quot;]/h4[@class=&quot;section-title text-primary&quot;]</value>
      <webElementGuid>fb67a78f-acaa-4abc-81e4-5007a4a3ea6c</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='page-content']/div[2]/div/div/div/div/h4</value>
      <webElementGuid>c35c0163-4232-4e78-b6d6-a969e3a6e9b6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Read Manual'])[1]/following::h4[1]</value>
      <webElementGuid>46c88236-5aec-48a3-8f6f-eb07e7c94037</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Business Messages Conversation Channel'])[1]/following::h4[1]</value>
      <webElementGuid>4f6cab1f-b42d-49fb-9f3e-ef0076519603</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='JE'])[1]/preceding::h4[1]</value>
      <webElementGuid>b747ad56-65d9-4291-83e9-ec972404d4cb</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Unclaimed Conversations']/parent::*</value>
      <webElementGuid>9e9cb013-70e4-46d8-8176-0bb8c63c8686</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//h4</value>
      <webElementGuid>5b793a73-4d59-4484-8a98-87c3fcfdbe94</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//h4[(text() = 'Unclaimed Conversations (7)' or . = 'Unclaimed Conversations (7)')]</value>
      <webElementGuid>57395335-27c0-453b-adb0-059c61f2beda</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
