<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>h4_Claimed Conversations (28)</name>
   <tag></tag>
   <elementGuidId>47756f6e-6f87-4724-86b1-bba08eb38920</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='page-content']/div[2]/div/div/div[2]/h4</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.row.claimed-conversations > h4.section-title.text-primary</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>h4</value>
      <webElementGuid>438910ab-1bca-433e-b27e-138cfe6840a7</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>section-title text-primary</value>
      <webElementGuid>e66352c7-f2e5-4c35-a48f-caefd616d0a9</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Claimed Conversations (28)</value>
      <webElementGuid>81a38ecd-6262-4235-b553-e0036e15f4d9</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;page-content&quot;)/div[@class=&quot;business-messages-container container-fluid&quot;]/div[@class=&quot;row border-top&quot;]/div[@class=&quot;col-sm-12 col-md-4 col-lg-3 business-messages-border&quot;]/div[@class=&quot;row claimed-conversations&quot;]/h4[@class=&quot;section-title text-primary&quot;]</value>
      <webElementGuid>cf1fcb8b-dba5-43e0-a9a1-eb22efdf7f90</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='page-content']/div[2]/div/div/div[2]/h4</value>
      <webElementGuid>1a466b4c-0c8a-4e3a-ab8b-670861280740</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='**** ** *** ******* **** **** *****...'])[1]/following::h4[1]</value>
      <webElementGuid>3201d95a-8848-4496-aa32-ef03b3e3ba63</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Juliana de Carvalho'])[4]/following::h4[1]</value>
      <webElementGuid>89adcd66-ac88-4f4f-8df4-44cefea81d06</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Claimed Conversations']/parent::*</value>
      <webElementGuid>3e0c08c2-367b-4568-afc3-d9ac74dd3660</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div/div/div[2]/h4</value>
      <webElementGuid>ed71e22b-027c-4d23-bf09-85da798f9986</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//h4[(text() = 'Claimed Conversations (28)' or . = 'Claimed Conversations (28)')]</value>
      <webElementGuid>ba36985b-1cee-4f36-89c0-9ccac0cd2969</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
