<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>h4_Claimed Conversations (3)</name>
   <tag></tag>
   <elementGuidId>2910d823-f96b-444f-afc1-5f72abd376ad</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='page-content']/div[2]/div/div/div[2]/h4</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.row.claimed-conversations > h4.section-title.text-primary</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>h4</value>
      <webElementGuid>afb2f717-5e1b-410d-b54a-5777aae2e2e4</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>section-title text-primary</value>
      <webElementGuid>c7e2464d-9fe6-4cfe-a053-acfbd5041b6b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Claimed Conversations (3)</value>
      <webElementGuid>00fb3bd0-695e-4b77-8b70-3d8d3bd15070</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;page-content&quot;)/div[@class=&quot;business-messages-container container-fluid&quot;]/div[@class=&quot;row border-top&quot;]/div[@class=&quot;col-sm-12 col-md-4 col-lg-3 business-messages-border&quot;]/div[@class=&quot;row claimed-conversations&quot;]/h4[@class=&quot;section-title text-primary&quot;]</value>
      <webElementGuid>103e8806-8741-476f-b0d1-e461b7438683</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='page-content']/div[2]/div/div/div[2]/h4</value>
      <webElementGuid>c67a3690-5925-4ed6-9288-a71392d0ac86</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='*** ***** *******'])[1]/following::h4[1]</value>
      <webElementGuid>5f828fa8-5ae1-4ea6-b38c-29a26f0bcb40</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Rahul Menon'])[1]/following::h4[1]</value>
      <webElementGuid>562c0813-ccb5-465e-96a2-6da70b2f3bee</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Claimed Conversations']/parent::*</value>
      <webElementGuid>047a9882-efd8-45fb-a274-2028f5f9e18b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div/div/div[2]/h4</value>
      <webElementGuid>d862631d-ea53-49bb-8d11-49080411068e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//h4[(text() = 'Claimed Conversations (3)' or . = 'Claimed Conversations (3)')]</value>
      <webElementGuid>95256f1e-f4cc-4904-91b7-f2f6862243a0</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
