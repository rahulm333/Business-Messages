<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Rahul Menon                            _80674d</name>
   <tag></tag>
   <elementGuidId>9df5c5df-23fc-46d2-8bc6-e593bcd1c845</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='55']/div[2]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>#55 > div.col-sm-10.bm-card-container</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>bdf086fe-c435-4343-abfe-e1d4576ccd16</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>col-sm-10 bm-card-container</value>
      <webElementGuid>53786146-6dd0-4e27-b9d2-d5b073947a96</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                        
                            Rahul Menon
                            07-05 
                        
                        Message @ 5.44 pm
                        Claimed by you
                    </value>
      <webElementGuid>59f5f7a8-93b3-40f5-976d-8df2b02c9183</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;55&quot;)/div[@class=&quot;col-sm-10 bm-card-container&quot;]</value>
      <webElementGuid>96bc90b6-e588-4a4f-a542-b918428996e6</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>98042285-e1cf-45d6-a0f3-2981ecbe4266</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>col-sm-10 bm-card-container</value>
      <webElementGuid>f3a0686b-2811-4c85-bafd-3935087a749b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                        
                            Rahul Menon
                            07-05 
                        
                        Message @ 5.44 pm
                        Claimed by you
                    </value>
      <webElementGuid>bcd68788-4ed0-4423-9c04-d865d7efb635</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;55&quot;)/div[@class=&quot;col-sm-10 bm-card-container&quot;]</value>
      <webElementGuid>15d718b2-25fa-4daa-95d7-4d6945746ad5</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='55']/div[2]</value>
      <webElementGuid>2d975746-8059-4616-a9fd-6baac47227e0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='RM'])[2]/following::div[1]</value>
      <webElementGuid>d743b231-dbe7-41b8-843b-45ca6181920f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='(3)'])[1]/following::div[5]</value>
      <webElementGuid>8d059a59-9fbf-4bf8-ba98-2d92f9253e25</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div/div/div[2]/div/div/div/div/div[2]</value>
      <webElementGuid>31ed392d-187b-46ce-9324-52ce6cd5fc63</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = '
                        
                            Rahul Menon
                            07-05 
                        
                        Message @ 5.44 pm
                        Claimed by you
                    ' or . = '
                        
                            Rahul Menon
                            07-05 
                        
                        Message @ 5.44 pm
                        Claimed by you
                    ')]</value>
      <webElementGuid>c2044679-fceb-49ce-84e0-ebdc06d0a1b2</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
