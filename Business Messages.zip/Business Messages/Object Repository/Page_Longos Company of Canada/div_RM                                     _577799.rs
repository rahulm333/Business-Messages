<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_RM                                     _577799</name>
   <tag></tag>
   <elementGuidId>50ed8eea-c4a3-4f67-8b8a-20d020ef415d</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@class='bm-card']</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>#56</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>07b28b8d-335b-4567-85c2-50719b60672f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>bm-card active</value>
      <webElementGuid>9e34a1ef-b8c3-4be9-9d88-07a91d3477df</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>56</value>
      <webElementGuid>c7e35908-767f-48dd-affb-d29679beac9e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                    RM
                    
                        
                            Rahul Menon
                            07-05 
                        
                        ******* * **** **
                        
                    
                </value>
      <webElementGuid>4e15331b-ee3c-4733-b272-9940e0f8070b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;56&quot;)</value>
      <webElementGuid>1245b6e5-0fd4-42d5-8336-070ef615ba82</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//div[@id='56']</value>
      <webElementGuid>b00622d7-1428-4cda-a963-1cbee48bbbf1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='unclaimed-conversations']/div</value>
      <webElementGuid>bfca961d-f0a3-4e0d-85b6-5e4ba5ea5789</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='(10)'])[1]/following::div[2]</value>
      <webElementGuid>f4102168-09b9-4711-a484-561dabefc4a8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[3]/div[2]/div/div/div/div/div[2]/div</value>
      <webElementGuid>19530f91-5cf5-4178-94c5-94202fa4ce25</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[@id = '56' and (text() = '
                    RM
                    
                        
                            Rahul Menon
                            07-05 
                        
                        ******* * **** **
                        
                    
                ' or . = '
                    RM
                    
                        
                            Rahul Menon
                            07-05 
                        
                        ******* * **** **
                        
                    
                ')]</value>
      <webElementGuid>1cb5e7df-a3e7-4f7b-b1b2-d0490c85efbb</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
