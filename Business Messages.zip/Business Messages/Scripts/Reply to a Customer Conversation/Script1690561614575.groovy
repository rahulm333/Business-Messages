import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys

WebUI.openBrowser('')

WebUI.maximizeWindow()

WebUI.navigateToUrl('https://staging.manage.dacgroup.com/auth/sign_in')

WebUI.setText(findTestObject('Object Repository/Page_beta DAC AuthCenter/input_Username_userusername'), 'rmenon@dacgroup.com')

WebUI.setEncryptedText(findTestObject('Object Repository/Page_beta DAC AuthCenter/input_Password_userpassword'), '+sZdR7HaPi5kY/9GD7Z5CA==')

WebUI.click(findTestObject('Object Repository/Page_beta DAC AuthCenter/input_Remember me_commit'))

WebUI.setText(findTestObject('Object Repository/Page_beta DAC AuthCenter/input_Accounts_searchfield_value'), 'neural')

WebUI.click(findTestObject('Object Repository/Page_beta DAC AuthCenter/input_Remember me_commit'))

WebUI.click(findTestObject('Object Repository/Page_beta DAC AuthCenter/img'))

WebUI.click(findTestObject('Object Repository/Page_beta DAC AuthCenter/a_Phoenix Dashboard'))

WebUI.switchToWindowTitle('Longos Company of Canada')

WebUI.click(findTestObject('Object Repository/Page_Longos Company of Canada/span_Inbox'))

WebUI.takeFullPageScreenshot()

WebUI.click(findTestObject('Object Repository/Page_Longos Company of Canada/div_Rahul Menon                            _80674d'))

WebUI.takeFullPageScreenshot()

WebUI.setText(findTestObject('Object Repository/Page_Longos Company of Canada/input_Request to claim_msgText'), 'Reply to message on 2023-08-08')

WebUI.delay(5)

WebUI.click(findTestObject('Object Repository/Page_Longos Company of Canada/button_Send'))

WebUI.delay(15)

WebUI.takeFullPageScreenshot()

WebUI.delay(10)

WebUI.closeBrowser()

